Audio File Arranger
-------------------

This will help to categorise mp3 file based on
Album, Artist and Album Artist.

All the unorganized mp3 file in the source path
will get organized based on album, artist or album artist
in destination path.

Requirement
-----------

eyeD3


Installation
------------

pip install eyeD3
